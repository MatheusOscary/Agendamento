<?php
class Agendamento {
    private int $codAgendamento;
    private int $codUsuario;
    private int $codCliente;
    private int $codLoja;
    private int $codServico;
    private string $inicia;
    private string $termina;
    private string $dataCadastrou;
    private string $sessaoCadastrou;
    private ?string $dataAtualizou;
    private ?string $sessaoAtualizou;

    public function __construct(
        int $codAgendamento = 0,
        int $codUsuario = 0,
        int $codCliente = 0,
        int $codLoja = 0,
        int $codServico = 0,
        string $inicia = '',
        string $termina = '',
        string $dataCadastrou = '',
        string $sessaoCadastrou = '',
        ?string $dataAtualizou = null,
        ?string $sessaoAtualizou = null
    ) {
        $this->codAgendamento = $codAgendamento;
        $this->codUsuario = $codUsuario;
        $this->codCliente = $codCliente;
        $this->codLoja = $codLoja;
        $this->codServico = $codServico;
        $this->inicia = $inicia;
        $this->termina = $termina;
        $this->dataCadastrou = $dataCadastrou;
        $this->sessaoCadastrou = $sessaoCadastrou;
        $this->dataAtualizou = $dataAtualizou;
        $this->sessaoAtualizou = $sessaoAtualizou;
    }

    public function getCodAgendamento(): int {
        return $this->codAgendamento;
    }

    public function getCodUsuario(): int {
        return $this->codUsuario;
    }

    public function getCodCliente(): int {
        return $this->codCliente;
    }

    public function getCodLoja(): int {
        return $this->codLoja;
    }

    public function getCodServico(): int {
        return $this->codServico;
    }

    public function getInicia(): string {
        return $this->inicia;
    }

    public function getTermina(): string {
        return $this->termina;
    }

    public function getDataCadastrou(): string {
        return $this->dataCadastrou;
    }

    public function getSessaoCadastrou(): string {
        return $this->sessaoCadastrou;
    }

    public function getDataAtualizou(): ?string {
        return $this->dataAtualizou;
    }

    public function getSessaoAtualizou(): ?string {
        return $this->sessaoAtualizou;
    }

    public function setCodAgendamento(int $codAgendamento): void {
        $this->codAgendamento = $codAgendamento;
    }

    public function setCodUsuario(int $codUsuario): void {
        $this->codUsuario = $codUsuario;
    }

    public function setCodCliente(int $codCliente): void {
        $this->codCliente = $codCliente;
    }

    public function setCodLoja(int $codLoja): void {
        $this->codLoja = $codLoja;
    }

    public function setCodServico(int $codServico): void {
        $this->codServico = $codServico;
    }

    public function setInicia(string $inicia): void {
        $this->inicia = $inicia;
    }

    public function setTermina(string $termina): void {
        $this->termina = $termina;
    }

    public function setDataCadastrou(string $dataCadastrou): void {
        $this->dataCadastrou = $dataCadastrou;
    }

    public function setSessaoCadastrou(string $sessaoCadastrou): void {
        $this->sessaoCadastrou = $sessaoCadastrou;
    }

    public function setDataAtualizou(?string $dataAtualizou): void {
        $this->dataAtualizou = $dataAtualizou;
    }

    public function setSessaoAtualizou(?string $sessaoAtualizou): void {
        $this->sessaoAtualizou = $sessaoAtualizou;
    }
}
?>
