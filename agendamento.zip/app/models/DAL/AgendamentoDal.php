<?php
require_once __DIR__ .'/../Conexao.php';
require_once __DIR__ .'/../Agendamento.php';

class AgendamentoDal{
    private $conn;

    public function __construct() {
        $conexao = new Conexao();
        $this->conn = $conexao->conectar();
    }
    public function select($data, $codUsuario){
        $sql = "SELECT * FROM Agendamento WHERE Cod_usuario = ". $codUsuario ." AND DATE(Inicia) = '". $data ."' AND DATE(Termina) = '". $data ."' " ;
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        
        $Agendamentos = [];
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $agendamento = new Agendamento();
    
            $agendamento->setCodAgendamento($row['Cod_agendamento']);
            $agendamento->setCodUsuario($row['Cod_usuario']);
            $agendamento->setCodCliente($row['Cod_cliente']);
            $agendamento->setCodLoja($row['Cod_loja']);
            $agendamento->setCodServico($row['Cod_servico']);
            $agendamento->setInicia($row['Inicia']);
            $agendamento->setTermina($row['Termina']);
            $agendamento->setDataCadastrou($row['Data_cadastrou']);
            $agendamento->setSessaoCadastrou($row['Sessao_cadastrou']);
            $agendamento->setDataAtualizou($row['Data_atualizou']);
            $agendamento->setSessaoAtualizou($row['Sessao_atualizou']);
    
            $Agendamentos[] = $agendamento;
        }
        return $Agendamentos;
    }

    public function gerarIntervalosAgendados($data, $codUsuario) {
        $agendamentos = $this->select($data, $codUsuario);
        $intervalosAgendados = [];
    
        foreach ($agendamentos as $agendamento) {
            $inicia = date('H:i', strtotime($agendamento->getInicia()));
            $termina = date('H:i', strtotime($agendamento->getTermina()));
            $intervalosAgendados[] = [$inicia, $termina];
        }
    
        return $intervalosAgendados;
    }
    
}
?>