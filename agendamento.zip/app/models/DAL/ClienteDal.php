<?php
require_once __DIR__ .'/../Conexao.php';
require_once __DIR__ .'/../Cliente.php';

class ClienteDal{
    private $conn;

    public function __construct() {
        $conexao = new Conexao();
        $this->conn = $conexao->conectar();
    }

    public function insert(Cliente $cliente){
        $sql = "INSERT INTO Cliente(Nome, Telefone, Genero, UF, Cidade, CEP, Bairro, Rua, Numero, Data_aniversario, Data_cadastrou, Sessao_cadastrou, Cod_loja) VALUES('". $cliente->getNome() ."', '". $cliente->getTelefone() ."', '". $cliente->getGenero() ."', '". $cliente->getUf() ."', '". $cliente->getCidade() ."', '". $cliente->getCep() ."', '". $cliente->getBairro() ."', '". $cliente->getRua() ."', '". $cliente->getNumero() ."', '". $cliente->getDataAniversario() ."', NOW(), ". $_SESSION["Sessao"] .", ". $_SESSION["Cod_loja"] .")";

        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
    }
    
    public function select(Cliente $cliente) {
        $sql = "SELECT * FROM Cliente WHERE 1=1 AND Cod_loja = ". $_SESSION["Cod_loja"];
        
        if ($cliente->getNome()) {
            $sql .= " AND Nome LIKE '%" . $cliente->getNome() . "%'";
        }
        if ($cliente->getTelefone()) {
            $sql .= " AND Telefone LIKE '%" . $cliente->getTelefone() . "%'";
        }
        if ($cliente->getUf()) {
            $sql .= " AND UF = '" . $cliente->getUf() . "'";
        }
        if ($cliente->getCidade()) {
            $sql .= " AND Cidade LIKE '%" . $cliente->getCidade() . "%'";
        }
        if ($cliente->getCep()) {
            $sql .= " AND CEP LIKE '%" . $cliente->getCep() . "%'";
        }
        if ($cliente->getBairro()) {
            $sql .= " AND Bairro LIKE '%" . $cliente->getBairro() . "%'";
        }
        if ($cliente->getRua()) {
            $sql .= " AND Rua LIKE '%" . $cliente->getRua() . "%'";
        }
        if ($cliente->getDataAniversario()) {
            $sql .= " AND Data_aniversario = '" . $cliente->getDataAniversario() . "'";
        }
        //echo $sql;
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        
        $clientes = [];
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $clienteObj = new Cliente();
            $clienteObj->setNome($row['Nome']);
            $clienteObj->setTelefone($row['Telefone']);
            $clienteObj->setGenero($row['Genero']);
            $clienteObj->setUf($row['UF']);
            $clienteObj->setCidade($row['Cidade']);
            $clienteObj->setCep($row['CEP']);
            $clienteObj->setBairro($row['Bairro']);
            $clienteObj->setRua($row['Rua']);
            $clienteObj->setNumero($row['Numero']);
            $clienteObj->setDataAniversario($row['Data_aniversario']);
            $clienteObj->setDataCadastrou($row['Data_cadastrou']);
            
            $clientes[] = $clienteObj; 
        }
        
        return $clientes;
    }
    
}
?>