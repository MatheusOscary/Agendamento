<?php
require_once '../app/models/BLL/HorarioBll.php';

ini_set('session.gc_maxlifetime', 3600);
ini_set('session.cookie_lifetime', 3600);
session_start();
$horarioDal = new HorarioDal();
$intervalos = $horarioDal->array_horario_atendimento('segunda', $_SESSION["Cod_usuario"]);

function obterHorariosDisponiveis($servicoDuracao, $intervalosAtendimento, $intervalosAgendados) {
    $horariosDisponiveis = [];

    foreach ($intervalosAtendimento as $intervalo) {
        list($inicio, $fim) = $intervalo;
        $horarioAtual = $inicio;

        // Cria objetos DateTime para facilitar a manipulação
        $inicioDateTime = new DateTime($inicio);
        $fimDateTime = new DateTime($fim);

        while ($inicioDateTime < $fimDateTime) {
            // Converte o horário atual para uma string
            $horarioAtualStr = $inicioDateTime->format('H:i');
            $horarioFim = clone $inicioDateTime;
            $horarioFim->modify("+$servicoDuracao minutes");

            // Verifica se o horário de término está dentro do intervalo
            if ($horarioFim <= $fimDateTime) {
                // Verifica se o novo agendamento se sobrepõe a algum agendamento existente
                $disponivel = true;
                foreach ($intervalosAgendados as $intervaloAgendado) {
                    list($agendadoInicio, $agendadoFim) = $intervaloAgendado;
                    $agendadoInicioDateTime = new DateTime($agendadoInicio);
                    $agendadoFimDateTime = new DateTime($agendadoFim);

                    // Verifica se o novo horário se sobrepõe ao agendado
                    if ($inicioDateTime < $agendadoFimDateTime && $horarioFim > $agendadoInicioDateTime) {
                        $disponivel = false;
                        break; // Sai do loop se encontrar uma sobreposição
                    }
                }

                if ($disponivel) {
                    $horariosDisponiveis[] = "$horarioAtualStr-" . $horarioFim->format('H:i');
                }
            }

            // Incrementa o horário atual pela duração do serviço
            $inicioDateTime->modify("+{$servicoDuracao} minutes");
        }
    }

    return $horariosDisponiveis;
}

// Exemplo de uso
$intervalosAtendimento = [["08:00", "13:00"], ["14:00", "18:00"]];
$intervalosAgendados = [["08:00", "08:30"], ["09:00", "09:30"], ["14:00", "15:00"]]; // Exemplo de horários já ocupados
$servicoDuracao = 30; // Duração do serviço em minutos

$horariosDisponiveis = obterHorariosDisponiveis($servicoDuracao, $intervalos, $intervalosAgendados);

// Exibir os horários disponíveis de forma bonita
foreach ($horariosDisponiveis as $horario) {
    echo $horario . "<br>";
}


?>